  <footer>            
        <div style="max-height:50px"><img src="https://webwise.wales/wp-content/uploads/2017/05/webwise-tagline-white.svg" style="max-height:40px"/></div>
  </footer>
</div>
  <script>
    var _gaq=[['_setAccount','UA-XXXXX-X'],['_trackPageview']];
    (function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
    g.src=('https:'==location.protocol?'//ssl':'//www')+'.google-analytics.com/ga.js';
    s.parentNode.insertBefore(g,s)}(document,'script'));
  </script>
			   
  <?php wp_footer(); ?>
  <link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">

</body>
</html>